//fatima noor & hammad riz
//8009 & 8021
//question 5-12 c
//5.12

#include < iostream>                  //including libraries
using namespace std;

int main()                             //starting the main function
{

	for (int i = 10; i > 0; i--)      //beginning the main for loop
	{
		for (int j = 10; j > 0; j--)  //beginning the nested for loop
		{
			cout << (j <= i ? "*" : " ");
		}
		cout << endl;
	}                                 //ending the main for loop

	system("PAUSE");
	return 0;
}