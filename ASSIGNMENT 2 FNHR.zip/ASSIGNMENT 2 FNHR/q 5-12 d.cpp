//fatima noor & hammad riaz
//mts 37 a
//reg no :8009 & 8021
//question 5-12 d

#include < iostream>                      //including libraries
using namespace std;
int main()
{

	for (int i = 1; i <= 10; i++)          //applying the main for loop
	{
		for (int j = 10; j >= 1; j--)      //applying the nested for loop
		{
			if (j <= i)                    //applying if  condition
				cout << "*";               //displaying output
			else
				cout << " ";
		}                                  //ending nested for loop
		cout << endl;
	}                                      //ending main for loop

	system("PAUSE");
	return 0;
}