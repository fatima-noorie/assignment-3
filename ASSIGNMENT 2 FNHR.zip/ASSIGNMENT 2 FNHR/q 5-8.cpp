//fatima noor & hammad riaz
//8009 & 8021 
//mts 3 A
//assignment no 2
//question no 5-8
#include <iostream>                              //including libraries
using namespace std;
int main()
{
	int i;                                        //initiaizing the integer for increment
	int smallest_integer;                          //initializing the variable for smallest no
	cout << "Enter the no of integers you want to check "<< endl;      //prompting the user about no of integers to check
	cin >> i;
	cout << "enter the integers" << endl;           //taking in the integers to check
	cin >> smallest_integer;

	for (i; i > 1; i--)                         //begining the for loop
	{
		int a;
		cin >> a;
		if (a< smallest_integer)                       //check if entered no is smallest than the previous one
			smallest_integer = a;                       
	}
	cout << "Smallest integer is " << smallest_integer << endl;    //displaying the smallest integer
	system("PAUSE");

}
