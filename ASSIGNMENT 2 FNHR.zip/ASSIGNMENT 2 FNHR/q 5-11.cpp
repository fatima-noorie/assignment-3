//fatima noor(8009) &hammad riaz(8021)
//algos and programming
//q 5-11
#include < iostream>
#include < iomanip>
#include < cmath>                                                         // including math library
using namespace std;

int main()
{
	float amount;                                                         //intializing amount on deposit at end of each year as a float 
	float principal;                          

	cout << fixed << setprecision(2);                                     // set floating-point number format

	for (int rate = 5; rate <= 10; rate++)                                //starting the for loop
	{

		principal = 1000.0;                                               //declaring the initial value of principal
		cout << "for intrest rate of " << rate << endl;
		cout << setw(4) << " Year" << setw(9) << "Dep.(%X)" << endl;      //setting the alignment in tabular form
		for (int year = 1; year <= 10; year++)                            //nested for within for for increasing the intrest rate
		{
			principal = principal * pow(1 + rate / 100.0, year);
			cout << setw(4) << year << setw(9) << principal << endl;      //setting the float presision
		}                                                                 //ending nestedfor loop

		cout << endl;                                                     //leaving one line space after every set of calculation
	}                                            
	system("pause");

	return 0; 
}