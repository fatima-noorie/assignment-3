
//fatima noor(8009) & hammad riaz(8021)
//mts 37 a
//assignment 2
//algos and programming
//factorials from 1 to 5
//q 5-10
#include < iostream>                                 //including libraries
using namespace std;

int main()                                            //starting the main function
{
	int x = 1;                                        //initializing the integer x

	for (int i = 1; i <= 5; i++)                      //using the for loop to calculate factorial
	{
		x =x* i;
		cout << " Factorial of " << i << " is\t " << x<<endl;
	}
	return 0;
}
