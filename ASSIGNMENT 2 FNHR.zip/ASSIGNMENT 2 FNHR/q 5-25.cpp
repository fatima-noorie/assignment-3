//fatima noor & hammad riaz
//8009 & 8021
//q 5-25
//assignment 2

#include <iostream>                                       //including  input/output libraries
using namespace std; 
int main() 
{ int count;                                              // control variable also used afterloopterminates 9 10
for (count = 1;count < 5;++count)                         // loop 5 times 
{
	
	cout << count << ""; 
 }                                                        // ending for loop
cout << "\nBroke outofloopatcount="<< count<<endl; 
}