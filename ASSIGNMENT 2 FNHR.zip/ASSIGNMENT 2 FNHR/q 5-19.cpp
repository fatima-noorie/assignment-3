//fatima noor & hammad riaz
//mts 37 a
//algo and programming 
//8009 & 8021
//mts 37 a
//assignment 2
//approx value of pie
#include<iostream>                                               //including libraries
using namespace std;
int main()
{
	double y = 1.0;                                              //initializing variables
	double x = 0.0;
	double ans = 0.0;
	
	
		for (int j =1 ;; j++ )                                  //beginning the infinity for loop
		{
	
	        for (int i = 1; i <= 500; i++)                     //beginning the nested for loop
	             {                                             //we have selected 500 instead of 1000 bcoz one loop covers two expressions

		            x = (4 / y) - (4 / (y + 2));                //making up the series
		            y = y + 4;
		            ans = ans + x;

	              }
	    cout <<"ans after "<<j<<" thousand series addition=" <<ans<<endl;  //displaying the answers
         }
}