//fatima noor & hammad riaz
//8009 & 8021
//algo and programming
//mts 37 a
//printing diamond of astrieks
#include<iostream>
using namespace std;                                    //including the input/output libraries

int  main()
{                                                      //starting the main function
	int i, j, k;                                       //initializing the required integers

	for (i = 1; i <= 4; i++)                           //using a for loop for 4 times for upper triangular part
	{
		for (j = 4; j >= i; j--)                       //using a nested for loop for spaces
		{
			cout << " ";
		}
		for (k = 1; k <= (2 * i - 1); k++)             //using another for loop for astriks
		{
			cout << "*";
		}
		cout << "\n";
	}
	for (int x = 1; x <= 9; x++)                         //using  a for loop to print the central line of astreiks
	{
		cout << "*";                                     //printing the line of 9 astreiks
	}
	cout << endl;
	int l, m, n;
	for (l = 4; l >= 1; l--)                             //using another for loop for lower triangle
	{
		for (m = 5; m>l; m--)                           //now the nested for loop is used in reverse
		{
			cout << " ";
		}
		for (n = 1; n<(l * 2); n++)
		{
			cout << "*";
		}
		cout << "\n";
	}

}