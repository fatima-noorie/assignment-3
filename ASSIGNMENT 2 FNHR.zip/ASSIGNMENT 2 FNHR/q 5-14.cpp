//fatima noor & hammad riaz
//reg no:8009 &8021
//algo and programming
//question 5-14
//(Calculating Total Sales)
#include < iostream>                                 //including libraries
using namespace std;
int main()
{
	int number =0;                                   //initializing the required variables
	float quantity = 0.0;
	float quantity1 = 0.0, quantity2 = 0.0, quantity3 = 0.0, quantity4 = 0.0, quantity5 = 0.0;
	float amount1 = 0.0, amount2 =0.0, amount3 = 0.0, amount4 = 0.0, amount5 = 0.0;
	cout << "product.1   $2.98" << endl;              //displaying the products with values
	cout << "product.2   $4.50" << endl;
	cout << "product.3   $9.98" << endl;
	cout << "product.4   $4.49" << endl;
	cout << "product.5   $6.87" << endl;
	for (; number != -1;)                            //beginning the for loop
	{
		cout << "Enter product number " << endl;     //prompting the user to enterproduct no
		cin >> number;
		cout << "enter quantity sold" << endl;       //prompting the user for enter quatity sold
        cin >> quantity;
		cout<<"enter -1 to end" << endl;
		switch (number)
		{
		case 1:                                      //calculating the prices of product acc to given rate
			quantity1 += quantity;
			amount1 += quantity * 2.98;               //the switch command would follow the case according to the value of number
			break;
		case 2:
			quantity2 += quantity;
			amount2 += quantity * 4.50;
			break;
		case 3:
			quantity3 += quantity;
			amount3 += quantity * 9.98;
			break;
		case 4:
			quantity4 += quantity;
			amount4 += quantity * 4.49;
			break;
		case 5:
			quantity5 += quantity;
			amount1 += quantity * 6.87;
			break;
		default:
			cout << "Enter correct product number!" << endl;
			break;
		}

	}
	int total_quantity = quantity1 + quantity2 + quantity3 + quantity4 + quantity5;       //calc total quantity
	float total_amount = amount1 + amount2 + amount3 + amount4 + amount5;                 //calc total amt
	cout << "Sold product quantity: " <<total_quantity  << endl;                          //displaying total quantity and amount
	cout << "Sold product amount: " <<total_amount<<"$" << endl;
	system("PAUSE");
	return 0;
}
