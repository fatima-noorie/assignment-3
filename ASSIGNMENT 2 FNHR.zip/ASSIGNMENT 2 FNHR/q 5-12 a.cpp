//fatima noor(8021) & hammad riaz(8021)
//mts 37 a
//queston 5-12 (a)
//printing asietreks
//assignment 2
#include < iostream>                            //including libraries
using namespace std;
int main()
{
   for (int i = 1; i <= 10; i++)                //using the main for loop
	{
		for (int j = 1; j <=i; j++)             //nested for loop within for loop
		{
			cout <<  "*";                       //displaing the output
		}
		cout << endl;                           
	}                                           //ending the main for loop
	system("PAUSE");
	return 0;
}