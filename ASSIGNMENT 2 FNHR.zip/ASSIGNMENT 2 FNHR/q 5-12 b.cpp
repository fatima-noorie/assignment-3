//fatima noor(8009) & hammad riaz (8021)
//mts 37 a
//queston 5-12 (b)
//printing asietreks
//assignment 2
#include < iostream>                       //including libraries
using namespace std;
int main()
{

	for (int i = 10; i >= 1; i--)          //beginning the mmain for loop
	{
		for (int j = 1; j <= i; j++)       //for within for nested loop
		{
			cout <<  "*";                  //displaying the required output
		}
		cout << endl;
	}                                      //ending he main loop
	system("PAUSE");
	return 0;
}
