//fatima noor(8009) & hammad riaz(8021)
//mts 37 a
//algo and programming
//5.9

#include < iostream>                                                         //including libraries
using namespace std;
int main()
{
	int product = 1;                                                         //initializing the product 

	for (int i = 1; i <= 15; i++)                                            //starting the for loop
	{
		if (i % 2 == 1)                                                      //applying the cond for odd numbers 
			product = product* i;                                            //if no is odd than multiply
	}

	cout << "product of odd numbers from 1 to 15 is :" << product << endl;   //displaying the result
	system("PAUSE");
	return 0;
}