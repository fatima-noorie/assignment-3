//fatima noor & hammad riaz
//mts 37 a
//8009 & 8021
//algos and programming
//q 5-13
//(Bar Chart)

#include < iostream>                                                      //including the input/output libraries
using namespace std;
int main()
{
	int a;                                                                 //initializing the variables
	int b;
	int c;
	int d; 
	int e;
	cout << "Enter five integers (between 1 and 30): "<<endl;              //prompting the user to enter variales
	cin >> a >> b >> c >> d >> e;                                          //taking in variables as input
	cout << endl << endl << endl <<endl<< "bar chart;"                     //giving the required spaces
	cout << a;
	for (int i = 1; i <= a; i++)                                           //displaying bar for "a"
	{
		cout << "*";
	}
	cout << endl;
	cout << b;
	for (int i = 1; i <= b; i++)                                           //diplaying bar for "b"
	{
		cout << "*";
	}
	cout << endl;
	cout << c;
	for (int i = 1; i <= c; i++)                                           //diplaying bar for "c"
	{
		cout << "*";
	}
	cout << endl;
	cout << d;                                                             //diplaying bar for "d"
	for (int i = 1; i <= d; i++)
	{
		cout << "*";
	}
	cout << endl;
	cout << e;                                                             //diplaying bar for "e"
	for (int i = 1; i <= e; i++)
	{
		cout << "*";
	}
	cout << endl;
	system("PAUSE");
	return 0;
}